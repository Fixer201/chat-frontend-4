export interface Group {
    id: string
    name: string
    description?: string
    members: string[]
    createdAt: string
}
