// @shared/hooks/useAddContact.ts
import { useCallback, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useApiFetcher } from '@shared/hooks/useApiFetcher'
import { addContacts } from '@redux/slices/contactsSlice'
import { Contact } from '@shared/types/contact'
import toast from 'react-hot-toast'

// Интерфейс ответа от API (как в вашем примере)
interface ApiAddedContact {
    uid: string
    phone: string
    first_name: string
    last_name: string
    avatar: string | null
    avatar_url: string | null
    avatar_webp: string | null
    avatar_webp_url: string | null
    is_online: boolean
    was_online_at: number | null
}

interface UseAddContactReturn {
    addContact: (contact: Contact) => Promise<void>
    isAdding: boolean
    error: string | null
}

export function useAddContact(): UseAddContactReturn {
    const [isAdding, setIsAdding] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const fetchData = useApiFetcher()
    const dispatch = useDispatch()

    const addContact = useCallback(async (contact: Contact) => {
        // Проверяем наличие телефона
        if (!contact.phone) {
            console.error('Недостаточно данных для добавления контакта:', {
                phone: contact.phone,
                firstName: contact.firstName || '',
                lastName: contact.lastName || '',
                uid: contact.uid,
            })
            toast.error('Недостаточно данных для добавления контакта')
            return
        }

        setIsAdding(true)
        setError(null)

        try {
            // Формируем тело запроса
            const body = {
                phone: contact.phone,
                first_name: contact.firstName || '',
                last_name: contact.lastName || '',
            }
            
            console.log('Отправка запроса на добавление контакта:', body)

            // Отправляем запрос
            const response: ApiAddedContact = await fetchData(
                '/api/v1/contact/messenger-add-by-phone/',
                {
                    method: 'POST',
                    body: JSON.stringify(body),
                },
            )

            // Маппим ответ API в Contact и добавляем в Redux
            const newContact: Contact = {
                uid: response.uid,
                userUid: response.uid,
                username: '',
                nickname: contact.nickname || '',
                phone: response.phone,
                firstName: response.first_name,
                lastName: response.last_name,
                patronymic: '',
                avatar: response.avatar,
                avatarUrl: response.avatar_url,
                avatarWebp: response.avatar_webp,
                avatarWebpUrl: response.avatar_webp_url,
                additionalInformation: '',
                birthday: 0,
                chatId: 0,
                isOnline: response.is_online,
                wasOnlineAt: response.was_online_at,
            }

            // Добавляем в Redux store
            dispatch(addContacts(newContact))
            
            toast.success('Контакт добавлен')

        } catch (error: unknown) {
            console.error('Ошибка при добавлении контакта:', error)
            
            // Обработка ошибок по статусу
            if (error instanceof Error) {
                const errorMessage = error.message
                
                // Проверяем на ошибку "контакт уже существует"
                if (errorMessage.includes('400') && 
                    errorMessage.includes('Этот контакт уже существует')) {
                    // Контакт уже существует: не показываем ошибку, считаем успехом
                    toast.success('Контакт добавлен')
                    return
                }
                
                // Обработка разных кодов ошибок
                if (errorMessage.includes('401')) {
                    toast.error('Необходимо авторизоваться')
                } else if (errorMessage.includes('404')) {
                    toast.error('Пользователь с таким номером не найден')
                } else if (errorMessage.includes('500')) {
                    toast.error('Ошибка сервера, попробуйте позже')
                } else {
                    toast.error('Ошибка при добавлении контакта')
                }
                
                setError(errorMessage)
            } else {
                toast.error('Неизвестная ошибка при добавлении контакта')
                setError('Unknown error')
            }
            
            throw error
        } finally {
            setIsAdding(false)
        }
    }, [fetchData, dispatch])

    return { addContact, isAdding, error }
}




