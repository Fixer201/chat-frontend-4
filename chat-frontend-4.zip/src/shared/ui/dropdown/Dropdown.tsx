"use client";

import {
  Children,
  cloneElement,
  createContext,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type HTMLAttributes,
  type MutableRefObject,
  type ReactElement,
  type ReactNode,
  type MouseEvent as ReactMouseEvent,
  type Ref,
} from "react";
import { createPortal } from "react-dom";

import { cn } from "@shared/lib/utils";

type Placement = "bottom-start" | "bottom-end" | "top-start" | "top-end";

interface DropdownContextValue {
  isOpen: boolean;
  setOpen: (next: boolean) => void;
  triggerRef: MutableRefObject<HTMLElement | null>;
  menuRef: MutableRefObject<HTMLDivElement | null>;
  placement: Placement;
  offset: number;
  closeOnSelect: boolean;
}

const DropdownContext = createContext<DropdownContextValue | null>(null);

const useDropdownContext = () => {
  const context = useContext(DropdownContext);
  if (!context) {
    throw new Error("Dropdown compound components must be used within <Dropdown>");
  }
  return context;
};

const mergeRefs = <T,>(...refs: Array<Ref<T> | null | undefined>) => {
  return (value: T | null) => {
    refs.forEach((ref) => {
      if (!ref) return;
      if (typeof ref === "function") {
        ref(value);
      } else {
        ref.current = value;
      }
    });
  };
};

interface DropdownProps {
  children: ReactNode;
  open?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  placement?: Placement;
  offset?: number;
  closeOnSelect?: boolean;
}

function DropdownRoot({
  children,
  open,
  defaultOpen,
  onOpenChange,
  placement = "bottom-start",
  offset = 8,
  closeOnSelect = true,
}: DropdownProps) {
  const isControlled = typeof open === "boolean";
  const [uncontrolledOpen, setUncontrolledOpen] = useState(defaultOpen ?? false);
  const triggerRef = useRef<HTMLElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  const isOpen = isControlled ? Boolean(open) : uncontrolledOpen;

  const setOpen = useCallback(
    (next: boolean) => {
      if (!isControlled) {
        setUncontrolledOpen(next);
      }
      onOpenChange?.(next);
    },
    [isControlled, onOpenChange]
  );
const hasTrigger = useMemo(() => {
    const childrenArray = Children.toArray(children);
    return childrenArray.some(child => 
      (child as any)?.type === DropdownTrigger
    );
  }, [children]);

  useEffect(() => {
    if (!isOpen) return;

    const handleClickAway = (event: MouseEvent) => {
      const target = event.target as Node;
      if(!hasTrigger){
        if (menuRef.current?.contains(target)) {
          return;
        }
        setOpen(false);
        return;
      }
      if (menuRef.current?.contains(target) || triggerRef.current?.contains(target)) {
        return;
      }
      
      setOpen(false);
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickAway);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleClickAway);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [isOpen, setOpen, hasTrigger]);

  const value = useMemo<DropdownContextValue>(
    () => ({ isOpen, setOpen, triggerRef, menuRef, placement, offset, closeOnSelect }),
    [closeOnSelect, isOpen, offset, placement, setOpen]
  );

  return <DropdownContext.Provider value={value}>{children}</DropdownContext.Provider>;
}

interface DropdownTriggerProps {
  children: ReactElement;
}

function DropdownTrigger({ children }: DropdownTriggerProps) {
  const { isOpen, setOpen, triggerRef } = useDropdownContext();

  const child = Children.only(children) as ReactElement<any>;
  const existingRef = (child as any).ref as Ref<HTMLElement> | undefined;
  const existingOnClick = child.props?.onClick as
    | ((event: ReactMouseEvent<HTMLElement>) => void)
    | undefined;

  return cloneElement(child, {
    ref: mergeRefs<HTMLElement>(triggerRef, existingRef),
    onClick: (event: ReactMouseEvent<HTMLElement>) => {
      existingOnClick?.(event);
      if (event.defaultPrevented) return;
      setOpen(!isOpen);
    },
    "aria-haspopup": "menu",
    "aria-expanded": isOpen,
  });
}

interface DropdownContentProps extends HTMLAttributes<HTMLDivElement> {
  width?: number|string;
  className?: string;
  children: ReactNode;
  items?: DropdownItemProps[];
  manualPosition?: {
    top: number;
    left: number;
  }|null;
  minWidth?: number;
}

function DropdownContent({ 
  width = 250, 
  minWidth=120,
  className, 
  children, 
  items, 
  style, 
  manualPosition,
  ...props 
}: DropdownContentProps) {
  const { isOpen, triggerRef, menuRef, placement, offset } = useDropdownContext();
  const [position, setPosition] = useState<CSSProperties>({ opacity: 0 });
  const contentRef = useRef<HTMLDivElement>(null);
  const [contentWidth, setContentWidth] = useState<number | string>(width);
  const [isMeasuring, setIsMeasuring] = useState(false);
  
  useLayoutEffect(() => {
    if (!isOpen || manualPosition) return;

    const updatePosition = () => {
      if (!triggerRef.current || !menuRef.current) return;

      const triggerRect = triggerRef.current.getBoundingClientRect();
      const menuRect = menuRef.current.getBoundingClientRect();

      let top = triggerRect.bottom + offset + window.scrollY;
      let left = triggerRect.left + window.scrollX;

      if (placement.startsWith("top")) {
        top = triggerRect.top - offset - menuRect.height + window.scrollY;
      }

      if (placement.endsWith("end")) {
        left = triggerRect.right - menuRect.width + window.scrollX;
      }

      setPosition({
        top,
        left,
        opacity: 1,
      });
    };

    updatePosition();

    const handle = () => updatePosition();
    window.addEventListener("resize", handle);
    window.addEventListener("scroll", handle, true);

    return () => {
      window.removeEventListener("resize", handle);
      window.removeEventListener("scroll", handle, true);
    };
  }, [isOpen, offset, placement, triggerRef, menuRef, manualPosition]);

useEffect(() => {
    if (!isOpen) return;

    const measureWidth = () => {
      // Проверяем, что width строго равен строке 'auto'
      if (width === 'auto' && contentRef.current) {
        const contentElement = contentRef.current;
        const itemsElements = contentElement.querySelectorAll('.dropdown-item-content');
        let maxWidth = minWidth;
        
        itemsElements.forEach(item => {
          const itemWidth = item.scrollWidth;
          if (itemWidth > maxWidth) {
            maxWidth = itemWidth;
          }
        });
        
        // Используем requestAnimationFrame для асинхронного обновления состояния
        requestAnimationFrame(() => {
          setContentWidth(maxWidth + 48); // 24px padding с каждой стороны
        });
      } else {
        // Если width не 'auto', используем его значение
        setContentWidth(width);
      }
    };

    measureWidth();
  }, [width, isOpen, minWidth]);

  if (!isOpen) {
    return null;
  }
 const contentStyle: CSSProperties = manualPosition 
    ? { 
        width: contentWidth === 'auto' ? 'auto' : contentWidth,
        minWidth: minWidth,
        position: 'fixed' as const, 
        top: manualPosition.top, 
        left: manualPosition.left, 
        opacity: 1, 
        zIndex: 1000,
        ...(style as CSSProperties) 
      }
    : { 
        width:contentWidth === 'auto' ? 'auto' : contentWidth,
        minWidth: minWidth,
         ...position,
          ...(style as CSSProperties)
         };

  return createPortal(
    (
      <div
        ref={menuRef}
        role="menu"
        style={contentStyle}
        className={cn(
          "absolute z-[60] max-h-[calc(100vh-32px)] overflow-hidden rounded-xl bg-(--color-white-bg) shadow-(--color-context-shadow)",
          className
        )}
        {...props}
      >
        
          <div 
          ref={contentRef}
          className="flex max-h-[inherit] flex-col overflow-auto"
        >
          {items?.map((item, index) => (
            <DropdownItem key={`${item.label ?? index}-${index}`} {...item} />
          ))}
          {children}
        </div>
          
        
      </div>
    ),
    document.body
  );
}

interface DropdownItemProps extends HTMLAttributes<HTMLButtonElement> {
  label?: string;
  icon?: ReactNode;
  rightIcon?: ReactNode;
  danger?: boolean;
  disabled?: boolean;
  onSelect?: () => void;
  closeOnSelect?: boolean;
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  onMouseEnter?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  onMouseLeave?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  hasDivider?: boolean;
}

function DropdownItem({
  label,
  icon,
  rightIcon,
  danger,
  disabled,
  onClick,
  onSelect,
  className,
  closeOnSelect,
  children,
  onMouseEnter,
  onMouseLeave,
  hasDivider = false,
  ...props
}: DropdownItemProps) {
  const { setOpen, closeOnSelect: contextCloseOnSelect } = useDropdownContext();
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled) {
      event.preventDefault();
      return;
    }
    onClick?.(event);
    if (event.defaultPrevented) return;
    onSelect?.();
    if (closeOnSelect ?? contextCloseOnSelect) {
      setOpen(false);
    }
  };

  return (
    <>
    {hasDivider && (
        <div className="border-t border-(--color-black-alpha-20) my-1" />
      )}
    <button
      type="button"
      role="menuitem"
      disabled={disabled}
      onClick={handleClick}
       onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
      className={cn(
        "flex w-full items-center justify-between gap-4 px-4 py-[10px] text-left text-base font-normal leading-[130%] transition-colors duration-150 border-b border-(--color-black-alpha-20) last:border-b-0",
        disabled
          ? "cursor-not-allowed text-[#9CA3AF]"
          : danger
            ? "cursor-pointer text-(--color-system-red) hover:bg-(--color-system-red-surface)"
            : "cursor-pointer text-(--color-text-black) hover:bg-(--color-gray-light)",
        className
      )}
      {...props}
    >
      <span className="dropdown-item-content truncate flex-1">
            {label ?? children}
          </span>
      <div className="flex items-center gap-2 flex-shrink-0">
        {/* Иконка слева от текста (если нужна) */}
          {icon && (
            <span className="text-(--color-text-gray) w-5 h-5 flex items-center justify-center opacity-80">
              {icon}
            </span>
          )}
         
          
        </div>
       {/* Иконка справа от текста */}
        {rightIcon && (
          <span className="text-(--color-text-gray) w-5 h-5 flex items-center justify-center opacity-80">
            {rightIcon}
          </span>
        )}
    </button>
    </>
  );
}

const Dropdown = DropdownRoot as typeof DropdownRoot & {
  Trigger: typeof DropdownTrigger;
  Content: typeof DropdownContent;
  Item: typeof DropdownItem;
};

Dropdown.Trigger = DropdownTrigger;
Dropdown.Content = DropdownContent;
Dropdown.Item = DropdownItem;

export type { DropdownProps, DropdownItemProps };
export default Dropdown;

// Пример использования:
// <Dropdown>
//   <Dropdown.Trigger>
//     <Button variant="ghost">Меню</Button>
//   </Dropdown.Trigger>
//   <Dropdown.Content width={220}>
//     <Dropdown.Item onSelect={() => console.log("Ответить")}>
//       Ответить
//     </Dropdown.Item>
//     <Dropdown.Item icon={<CheckIcon />}>Выбрать</Dropdown.Item>
//     <Dropdown.Item danger icon={<TrashIcon />}>
//       Удалить
//     </Dropdown.Item>
//   </Dropdown.Content>
// </Dropdown>
